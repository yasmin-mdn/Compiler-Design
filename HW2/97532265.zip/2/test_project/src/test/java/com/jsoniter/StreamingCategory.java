package com.jsoniter;

public interface StreamingCategory {
}
