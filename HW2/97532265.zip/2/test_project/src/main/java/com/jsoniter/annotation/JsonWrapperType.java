package com.jsoniter.annotation;

public enum JsonWrapperType {
    BINDING,
    KEY_VALUE
}
