package com.jsoniter;

public enum ValueType {
    INVALID,
    STRING,
    NUMBER,
    NULL,
    BOOLEAN,
    ARRAY,
    OBJECT
}
